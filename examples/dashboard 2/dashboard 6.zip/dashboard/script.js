
$(document).ready(function() {
    var $table = $(".main");
    $table.on("mouseenter", "td", function() {
        var tdIndex = $(this).index() + 1;
        var $trs = $table.find("tr");

        $.each($trs, function(i, tr) {
            var $actualTd = $(tr).find("td:nth-child(" + tdIndex + ")");

            $(tr).find("td:nth-child(" + (tdIndex - 1) + ")").addClass("borderless");
            switch (i) {
                case 2:
                case 3:
                    var tdClass = i === 2 ? " point redbl" : "point blue";
                    $actualTd[0].innerHTML = "<div class='" + tdClass + "'>" + $actualTd[0].innerHTML + "</div>";
                    break;
            }
            $actualTd.addClass("highlighted");
        });
    });
    $table.on("mouseleave", "td", function() {
        $table.find("td").removeClass("highlighted point redbl blue borderless");
        var tdIndex = $(this).index() + 1;
        var $trs = $table.find("tr");

        $.each($trs, function(i, tr) {
            if (i == 2 || i == 3) {
                var $actualTd = $(tr).find("td:nth-child(" + tdIndex + ")");
                if ($actualTd.find(".point").length > 0) {
                    var unwrapedHtml = $actualTd.find(".point").contents().unwrap();
                    $actualTd.html(unwrapedHtml);
                }
            }
        });
    });
});


jQuery(document).ready(function(){
    jQuery('.scrollbar-macosx').scrollbar();
});

window.onload = function () {
    var chart = new CanvasJS.Chart("chartContainer",
        {

            title:{
                text: "",
                fontSize: 30
            },
            animationEnabled: true,
            axisX:{

                gridColor: "",
                tickColor: "",
                valueFormatString: ""

            },
            toolTip:{
                shared:true
            },
            theme: "theme2",
            axisY: {
                gridColor: "White",
                tickColor: "white"
            },
            legend:{
                verticalAlign: "center",
                horizontalAlign: "left"
            },
            data: [
                {
                    type: "line",
                    showInLegend: true,
                    lineThickness: 2,
                    name: "Processing",
                    markerType: "circle",
                    color: "#D0021B",
                    dataPoints: [
                        { x: new Date(2010,0,3), y: 650 },
                        { x: new Date(2010,0,5), y: 700 },
                        { x: new Date(2010,0,7), y: 710 },
                        { x: new Date(2010,0,9), y: 658 },
                        { x: new Date(2010,0,11), y: 734 },
                        { x: new Date(2010,0,13), y: 963 },
                        { x: new Date(2010,0,15), y: 847 },
                        { x: new Date(2010,0,17), y: 853 },
                        { x: new Date(2010,0,19), y: 869 },
                        { x: new Date(2010,0,21), y: 943 },
                        { x: new Date(2010,0,23), y: 970 },
                        { x: new Date(2010,0,24), y: 700 },
                        { x: new Date(2010,0,25), y: 710 },
                        { x: new Date(2010,0,26), y: 658 },
                        { x: new Date(2010,0,27), y: 734 },
                        { x: new Date(2010,0,28), y: 963 },
                        { x: new Date(2010,0,29), y: 847 },
                        { x: new Date(2010,0,30), y: 853 },
                        { x: new Date(2010,0,31), y: 869 },
                        { x: new Date(2010,0,32), y: 943 },
                        { x: new Date(2010,0,33), y: 970 }
                    ]
                },
                {
                    type: "line",
                    showInLegend: true,
                    name: "Advantage",
                    color: "#4A90E2",
                    lineThickness: 2,

                    dataPoints: [
                        { x: new Date(2010,0,3), y: 510 },
                        { x: new Date(2010,0,5), y: 560 },
                        { x: new Date(2010,0,7), y: 540 },
                        { x: new Date(2010,0,9), y: 558 },
                        { x: new Date(2010,0,11), y: 544 },
                        { x: new Date(2010,0,13), y: 693 },
                        { x: new Date(2010,0,15), y: 657 },
                        { x: new Date(2010,0,17), y: 663 },
                        { x: new Date(2010,0,19), y: 639 },
                        { x: new Date(2010,0,21), y: 673 },
                        { x: new Date(2010,0,23), y: 660 },
                        { x: new Date(2010,0,24), y: 560 },
                        { x: new Date(2010,0,25), y: 540 },
                        { x: new Date(2010,0,26), y: 558 },
                        { x: new Date(2010,0,27), y: 544 },
                        { x: new Date(2010,0,28), y: 693 },
                        { x: new Date(2010,0,29), y: 657 },
                        { x: new Date(2010,0,30), y: 663 },
                        { x: new Date(2010,0,31), y: 639 },
                        { x: new Date(2010,0,32), y: 673 },
                        { x: new Date(2010,0,33), y: 660 }
                    ]
                }


            ],
            legend:{
                cursor:"pointer",
                itemclick:function(e){
                    if (typeof(e.dataSeries.visible) === "undefined" || e.dataSeries.visible) {
                        e.dataSeries.visible = false;
                    }
                    else{
                        e.dataSeries.visible = true;
                    }
                    chart.render();
                }
            }
        });

    chart.render();
}